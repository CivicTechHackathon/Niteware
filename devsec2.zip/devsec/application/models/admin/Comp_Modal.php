<?php
 class Comp_Modal extends MY_Model{
      
      public function __contruct(){
          parent::__contruct();
        
      }

      


 }
?>