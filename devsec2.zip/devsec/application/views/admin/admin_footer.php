
<footer class="main-footer">
                <div class="footer">
                        <div class="container-fluid">
                            <div class="container">
                              <div class="row">
                                  <div class="col-sm-6">
                                    <h4 class="text-left">MADE WITH <i class="fa fa-heart contact-icon-color"></i> AND WITH <i class="fa fa-coffee contact-icon-color"></i> IN KARACHI</h4>
                                  </div>
                                  <div class="col-sm-6">
                                    <h4 class="text-right">COPYRIGHT &copy; DEVSEC</h4>
                                  </div>
                              </div>
                            </div>
                        </div>
                    </div>
        </footer>
</body>
</html>