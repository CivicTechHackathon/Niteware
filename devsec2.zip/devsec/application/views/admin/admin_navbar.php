<nav class="navbar navbar-default bh-main-navbar navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand"><span>DEVSEC</span></a>
            </div>
          <div class="navbar-collapse collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#"><i class="fa fa-bell"></i></a></li>
                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="<?php echo base_url();?>assets/website/images/shariq.jpg" alt="admin-user-img" class="img-circle img-responsive" width="30px">&nbsp;&nbsp;Muhammad Shariq</a>
                  <ul class="dropdown-menu">
                      <li class="text-center dropdown-li">
                          <div class="dropdown-img">
                          <img src="<?php echo base_url();?>assets/website/images/shariq.jpg" alt="admin-img" class="img-responsive img-circle" width="100%">
                        </div> 
                          <p>Muhammad Shariq - Web Developer<br><small>Member since 2010</small></p>
                        
                        </li>
                      <li>
                          <div class="container dropdown-content">
                              <div class="row">
                                  <div class="col-sm-6 text-left" ><button type="button" id="profile" class=" btn-default" >Profile</button></div>
                                  <div class="col-sm-6 text-right" ><button type="button " class="btn-default" id="logout">Sign Out</button></div>
                              </div>
                              
                          </div>
                      </li>
                  </ul>
                </li>
                <li><a href="#"></a></li>
            </ul>
        </div>
        </div>
    </nav>