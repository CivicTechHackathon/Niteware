
<div class="container-fluid">
<div class="row">

<ul class="nav nav-pills nav-stacked side-menu col-sm-2">
        <li><a href="">
         <img src="<?php echo base_url();?>assets/website/images/shariq.jpg" alt="admin-img" width="40px" class="img-circle"> Muhammad Shariq
        </a></li>
        <li><a href="<?php echo base_url();?>admin/personal">Personal Details</a></li>
        <li><a href="<?php echo base_url();?>admin/contactList" target="_blank">Contact List</a></li>
        <li><a href="<?php echo base_url();?>admin/LocatePhone">Locate Phone</a></li>
        <li><a href="<?php echo base_url();?>admin/RingPhone">Ring Your Phone</a></li>
        <li><a href="<?php echo base_url(); ?>admin/EraseData">Erase Phone Data</a></li>
        <li><a href="<?php echo base_url();?>admin/Backup">Backup Data</a></li>
        
    
    </ul>
