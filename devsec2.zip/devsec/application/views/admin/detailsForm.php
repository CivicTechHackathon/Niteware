<div class="container-fluid table-responsive event-table">
   
    <div class="container">
    <h1>Personal Details</h1><br><br>
        <div class="row">
   
        <div class="col-sm-6">
            <form action="" method="post">
                <div class="form-group">
                    <label for="name">Full Name*</label>
                    <input type="text" class="form-control" name="fullName" required placeholder="Muhammad Shariq">
                </div>
                <div class="form-group">
                    <label for="email">
                      Email*  
                    </label>
                    <input type="email" class="form-control" name="email" required placeholder="shariqx5@gmail.com">
                </div>
                <div class="form-group">
                    <label for="contactNo">
                      Contact Number
                    </label>
                    <input type="text" class="form-control" name="contactNo" required placeholder="03121234567">
                </div>
                <div class="form-group">
                    <label for="Device IMEI">
                      Device IMEI
                    </label>
                    <input type="text" class="form-control" name="contactNo" required placeholder="45782649087123">
                </div>
                <div class="form-group">
                    <label for="Device IMEI">
                      Device IMEI
                    </label>
                    <input type="text" class="form-control" name="contactNo" required placeholder="45782649087123">
                </div>
                <div class="form-group">
                    <label for="Device IMEI">
                      Device IMEI
                    </label>
                    <input type="text" class="form-control" name="contactNo" required placeholder="45782649087123">
                </div>
                <button class="btn btn-primary" type="submit">Update</button>
</form>
        </div>
        <div class="col-sm-6">
            <div class="user-img text-center">
                <img src="<?php echo base_url();?>assets/website/images/shariq.jpg" alt="User Image">
                 <div class="content">
                     <h4>Muhammad Shariq</h4>
                 </div>
            </div>
            
        </div>
        
    </div>
    </div>
</div>