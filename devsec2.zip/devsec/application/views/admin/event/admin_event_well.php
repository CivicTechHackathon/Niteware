<div class="well well-sm">
  <form action="" id="img-search-form" method="post" class="form-inline">
    <div class="form-group">
       <ul class="nav nav-pills event-category">
         <li class="active load-event"><a href="">All</a></li>
         <li class=" load-event" ><a href="published">Published</a></li>
         <li class="load-event"><a href="draft">Draft</a></li>
       </ul>
     </div>
    <div class="form-group pull-right">
      <input type="text" class="form-control" id="event-text" placeholder="Search" required>
      <button class="btn btn-info"  type="button" id="add-event" value="<?php echo $button_value;?>"><i class="fa fa-plus"></i> Add New</button>
    </div>

  </form>
</div>
