<!--This will load the well-->
<?php $this->view('admin/media/search_image'); ?>
<!--This will load the gallery-->
<?php $this->view('admin/media/gallery_images');?>
