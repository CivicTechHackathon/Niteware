<div class="col-sm-10 gallery-main-area sidebar-right-area">
	<div class="container-fluid gallery-container">
		<h2 id="pages-heading">Media</h2>
		<br><br>
		<div class="form-group text-right">
			<button class="btn btn-default" name="select-multiple" id="select-multiple">Select Multiple</button>
      <button class="btn btn-default" name="delete" id="delete-multiple">Delete</button>
		</div>
   <?php $this->view('admin/media/search_image');?>


	 <?php $this->view('admin/media/gallery_images'); ?>

	</div>

</div>
</div>

</div>
