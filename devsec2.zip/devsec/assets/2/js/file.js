$(document).ready(function(){


event_countdown();

//SMOOTH SCROL//////

$("#home-navbar a").click(function(event){

     var hash=this.hash;

     if(hash!=""){

         event.preventDefault();
         var navbar_height=$("#home-navbar").height();


         $('html,body').animate({
           scrollTop:$(hash).offset().top-navbar_height
         },1000);

       }

     });




/////MOUSE BUTTON CLICK/////////

$(".mouse-scroll").click(function(){
  $("html,body").animate({
     scrollTop:$("#ABOUT").offset().top-70
  },800,function(){
     window.location.hash="#ABOUT";
  })
})


    $(".owl-carousel").owlCarousel({
      loop:true,
      margin:10,
      nav : true,
      responsive:{
    0:{
        items:1
    },
    600:{
        items:3
    },
    1000:{
        items:4
    }
}

    }

    );

    //CODE FOR SET THE EVENT CAROUSEL

    $(".owl-prev,.owl-next").text("");
    $(".owl-dots").hide();
    $(".owl-prev").append("<i class='glyphicon glyphicon-chevron-left'></i>");
    $(".owl-next").append("<i class='glyphicon glyphicon-chevron-right'></i>");

////////////////////////////////////

    $(".carousel-item").hover(function(){
          $(this).animate({marginTop:'0px'},"fast")
 },function(){
     $(this).animate({marginTop:'20px'},"fast");
 });


 /*FUNCTION FOR LOADING THE BORDER IN HOMEPAGE CAROUSEL*/
// load_line();

 function load_line(){

     var line=$(".carousel-line");
     width=line.width();
     width=width+10;
     line.width(width);


     windowWidth=window.innerWidth;

     if(line.width()>windowWidth){
          line.css("width","0px");
          $(".carousel").carousel("next");
      }

    var time=setTimeout(load_line,45);
 }



////function for show the event countdown

function event_countdown(){

     var end_date="2018/3/28";

     var t=Date.parse(end_date)-Date.parse(new Date());
     var seconds=Math.floor((t/1000)%60);
     var minutes=Math.floor((t/1000/60)%60);
     var hours=Math.floor((t/1000/60/60)%24);
     var days=Math.floor(t/1000/60/60/24);

     $("#days").text(days);
     $("#hours").text(hours);
     $("#minutes").text(minutes);
     $("#seconds").text(seconds);

     setInterval(event_countdown,1000);
}



//function for show the modal
$(".member-div a").click(function(){
       $(this).modal("toggle");
});




});
