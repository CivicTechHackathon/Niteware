$(document).ready(function(){
  var image_src;
  var image;



     /*NEW FUNCTIONS OLD WILL BE DELETED IN NO NEED*/
     $("#add-event").click(function(event){
           event.preventDefault();
           $(".add-event-div").remove();
           var controller_method=$(this).val();
           ajax_call_for_event("",controller_method);
     });


     /*FUNCTION FOR LOADING THE EDIT VIEW*/
       $(".operation").click(function(event){
             event.preventDefault();
              $(".add-event-div").remove();
            var id= $(this).children().attr("href");
            var cont_method=$(this).attr("id");
            alert(id);
            ajax_call_for_event(id,cont_method);
       });


     /*FUNCTION FOR LOADING VIEW*/
     function ajax_call_for_event(id,cont_method){
       $.ajax({
          url:'http://localhost/uitcs_acm/codeignitor/admin/'+cont_method,
          type:"POST",
          data:{
            'id':id
          },
          dataType:'JSON',
          success:function(data){
            $(".well").after(data['view']);
          },
          error:function(XMLHttpRequest,textStatus,errorThrown){
             alert(textStatus+" "+errorThrown);
          }
       });

     }   //END OF FUNCTIONS


     /*FUNCTION FOR RUN SEARCH QUERY*/
     $("#event-text").keyup(function(){
         var value=$(this).val().toLowerCase();
         $("tbody tr").filter(function(){
            $(this).toggle($(this).text().toLowerCase().indexOf(value)>-1);
         });
       });


    /*FUNCTION FOR LOADING THE MEDIA MODAL IN EVENT*/
     $(".main-event-area").on('click','.img-div',function(){

       image=$(this).children("img");

      $(".event-modal").empty();
            $.ajax({
              url:'http://localhost/uitcs_acm/codeignitor/admin/events/load_media',
              dataType:'json',
              success:function(data){
                $(".event-modal").append(data['view']);
                $("#media-modal").modal('show');
              },
              error:function(XMLHttpRequest,textStatus,errorThrown){
                  alert(textStatus+" "+errorThrown);
              }
            })
     });


/*FUNCTION FOR FILTER THE TABLE WITH TYPE QUERY*/

$(".load-event").click(function(event){
      event.preventDefault();
      $(this).siblings(".active").removeClass("active");
      $(this).addClass("active");
      value=$(this).children().attr("href").toLowerCase();
      if(value!=""){
          $("tbody tr").filter(function(){
             $(this).toggle($(this).find(".status").text().toLowerCase().indexOf(value)>-1);
          });
      }else{
        $("tbody tr").show();
      }
});


/*FUNCTION FOR SELECT IMAGE FROM MEDIA*/
$("#modal-gallery").on("click",".gallery-col",function(event){
        event.preventDefault();
        var element=$(this).find("[src]");
        if(element.hasClass("img-select-border")){
           element.toggleClass("img-select-border img-thumbnail")
           src="";
        }
        else{
           var attr=element.attr("alt");
           alert(attr);
           if(typeof attr!='undefined'){
             $(".gallery-col").find(".img-select-border").toggleClass("img-thumbnail img-select-border");
              element.toggleClass("img-select-border img-thumbnail");
              src=element.attr("src");
           }
        }
});


/*FUNCTION FOR PLACING THE IMAGE ON THE PLACE WHERE IT HAS BEEN CLICK*/
 $("#insert-image").click(function(){
      if(src!=""){
         image.attr("src",src);
         $("#media-modal").modal("toggle");
         image.removeClass("hide");
         image.prev().addClass("hide");
      }
 });



 $(".main-event-area").on('click','.publish-event,.draft-event',function(event){
      event.preventDefault();

    var button_value=$(this).val();
    var event_title=$("#event-title").val();
    var id=$("#id").val();
    var event_date=$("#event-date").val();
    var event_des=$("#event-des").val();
    var event_img=$(".img-div").find("img").attr("src");
    alert(event_img);
    var fun_to_call;
    var error=validate_event_data(event_title,event_date,event_des,event_img);

    if(button_value.indexOf("Update")>-1)
         fun_to_call='update_event';
    else
         fun_to_call='add_event';


    if(!error){
          $.ajax(
            {
              url:'http://localhost/uitcs_acm/codeignitor/admin/events/'+fun_to_call,
              type:'POST',
              data:{
                'id':id,
                'event_title':event_title,
                'event_date':event_date,
                'event_des':event_des,
                'event_img':event_img,
                'button':button_value
              },
               success:function(){
                  window.location.reload();
              },
              error:function(XMLHttpRequest,textStatus,errorThrown)
              {
                alert(textStatus+" "+errorThrown);
              }
            }
          )
      }





 });

 /*FUNCTION FOR VALIDATING THE EVENT FORM DATA*/
 function validate_event_data(event_title,event_date,event_des,event_img){
   var error=false;
   if(event_title==""){
      $(".text-error").text("Field must contain value");
      error=true;
   }

   if(event_date==""){
     $("#title-error").text("Field must contain value");
     error=true;
   }

   if(event_des==""){
     $("#des-error").text("Field must contain value");
     error=true;
   }

   if(event_img.indexOf("hide")>-1){
     $(".image-error").text("Please select an image");
     error=true;
   }

   return error;
 }

var delete_row=[];
 /*FUNCTION FOR DELETE THE EVENTS*/
 $(".mark-delete").click(function(){
    var id=$(this).val();

    var result=find_and_remove(id,delete_row);
    if(result==""){
        delete_row.push(id);
    }

 });


 $(".dlt-operation").click(function(event){
   event.preventDefault();
   var id=$(this).children().attr("href");
   delete_row.push(id);
   $(".dlt_row").trigger('click');
 })


$(".dlt_row").click(function(event){
       event.preventDefault();
       var method=$(this).val();
       url="http://localhost/uitcs_acm/codeignitor/admin/"+method;

       if(delete_row.length>=0){
          var user_rep=window.confirm("You are going to delete events premanently\n Press 'OK' to confirm 'Cancel' for abort");
          if(user_rep){
            $.ajax({
              url:url,
              type:'POST',
              data:{
                'del_row':delete_row
              },
              success:function(){
                window.location.reload();
              }
            })
       }
     }
});




      /*FUNCTION FOR FINDING AND ID IN DELETE ARRAY AND REMOVE IT */
      function find_and_remove(id,array){
          alert("array is "+array);
           var index='';
           for(var i=0;i<array.length;i++){
              if(array[i]==id){
                index=i;
                break;
              }
           }

           if(index!='')
              array.splice(index,1);

           return index;
      }

});
