$(document).ready(function(){

    var delete_img=[];

     /*FUNCTION FOR LOADING THE IMAGE DETAILS IN THE MODAL*/

     /*FUNCTION FOR LOADING THE MODAL ON CLICK THE SPECIFIC IMAGE*/
     //WIll delete this function
     $(".gallery-main-area .gallery-container").on('click','.gallery-col-link',function(event){
          event.preventDefault();
          var file_id=$(this).attr("href");
          $("#mediaModal").remove();
          $.ajax(
            {
            url:'http://localhost/uitcs_acm/codeignitor/admin/media/load_img_modal',
            type:'POST',
            dataType:'json',
            data:{
              'id':file_id
            },
            success:function(data){

                $(".gallery-images").after(data['view']);
                $("#mediaModal").modal('show');
            },
            error:function(XMLHttpRequest,textStatus,errorThrown){
                alert(textStatus+" "+errorThrown);
            }
          });
    });


/*FUNCTION RESPONSIBLE FOR SENDING THE DELETE QUERY*/
     $(".gallery-container").on('click','#dlt_media',function(event){
           event.preventDefault();  //will prevent default click behaviour
        var id=[];
        var ul_element= $(this).parent().prev().find("#media-img-info");
        id.push(ul_element.prev().val());
        var file_name=ul_element.children("li:first").children("span").text();

        var user_rep=confirm("You are about to delete this item\nPress 'OK' to confirm or 'Cancel' to abort");
           if(user_rep){
                var url="media/delete";
                $(this).siblings("p").load(url,{
                  'id':id,
                  'file_name':file_name
                });

                $("#mediaModal").removeClass("show");
               window.location.reload();
           }


     });


     /*FUNCTION FOR UPLOADING MULTIPLE FILES*/

     $(".gallery-container").on('click','#add-media-btn',function(){
          $(".add-file").trigger("click");
          $(".add-file").change(function(){
               $("#add-media-form").trigger('submit');
      });

     });

    /*FUNCTION FOR ADDING NEW MEDIA INTO MEDIA LIBRARY*/
     $(".gallery-container").on('submit','#add-media-form',function(event){
         event.preventDefault();
       $.ajax(
         {
           url:'media/add_image',
           type:'POST',
           data:new FormData(this),
           success:function(data){
             image_query("","");    //function which will load the image view asychronously
            },
           processData:false,
           contentType:false,
           error:function(XMLHttpRequest,textStatus,errorThrown){
             alert(textStatus+" "+errorThrown);
           }
       });
     });


     /*FUNCTION FOR PERFORMING SEARCH QUERY*/
      $(".gallery-container").on('keyup','#search_text',function(event){
            var value=$(this).val().toLowerCase();
          $(".gallery-col").filter(function(){
              $(this).toggle($(this).find("[src]").attr("src").toLowerCase().indexOf(value)>-1);
              //  alert($(this).find(".gallery-col-link").children().attr("src").toLowerCase().indexOf(value)>-1);
            })
    });

  /*FUNCTION FOR LOADING CATEGORIES OF MEDIA*/
    $(".gallery-container").on('click','.load-media',function(event){
         event.preventDefault();
        var type=$(this).children().attr("href");
        image_query("",type);
        $(".media-category").find("li.active").removeClass("active");
        $(this).addClass("active");
    });


      function image_query(text,type){

        $.ajax(
          {
            url:'http://localhost/uitcs_acm/codeignitor/admin/media/search_img',
            type:'POST',
            data:{
               'search_text':text,
               'type':type
            },
            dataType:'json',
            success:function(data){
                $('.gallery-images').remove();
                $("#add-media").after(data['view']);
            },
            error:function(XMLHttpRequest,textStatus,errorThrown){
                alert(textStatus+" "+errorThrown);
            }
          }
        )
      }

      $("#search_text").keyup(function(){

            if($(this).val()==""){
                $("#search-img-btn").trigger('click');
            }

      });

      /*FUNCTION FOR ADDING AND REMOVING CLASSES MULTIPLES FILES */
      $("#select-multiple").click(function(){

         if($(this).hasClass("selection")){
               $(this).removeClass("selection");
               var image=$(".gallery-images").find(".select");
               image.removeClass("select");
               image.addClass("gallery-col-link");
               image.children().addClass("img-thumbnail");
               image.children().removeClass("img-select-border");
               $(this).text("Select Multiple");
               delete_img.length=0;
         }
         else{
            $(this).addClass("selection");
            var image=$(".gallery-images").find(".gallery-col-link");
            image.removeClass("gallery-col-link");
            image.addClass("select");
            $(this).text("Cancel");

          }
      });


      /*FUNCTION FOR DELETING MULTIPLE ITEMS*/
      $(".gallery-col").on('click','.select',function(event){
          event.preventDefault();
          var id=$(this).attr("href");
           var img=$(this).children();

           if(img.hasClass("img-thumbnail")){
            img.addClass("img-select-border");
            img.removeClass("img-thumbnail");
            delete_img.push(id);

         }
         else{
             find_and_remove(id,delete_img);
             img.addClass("img-thumbnail");
             img.removeClass("img-select-border");

         }
           alert(delete_img);
      });




      /*FUNCTION FOR DELETING THE ELEMNT*/
      $("#delete-multiple").click(function(){
            if(typeof delete_img !=='undefined' && delete_img.length>0){
                 $.ajax({
                    url:'http://localhost/uitcs_acm/codeignitor/admin/media/delete',
                    type:'POST',
                    data:{
                      'id':delete_img
                    },
                    success:function(){
                       window.location.reload();
                    },
                     error:function(XMLHttpRequest,textStatus,errorThrown){
                      alert(textStatus+" "+errorThrown);
                    }
                 })
            }
      });


      /*FUNCTION FOR FINDING AND ID IN DELETE ARRAY AND REMOVE IT */
      function find_and_remove(id){

           for(var i=0;i<delete_img.length;i++){
               if(delete_img[i]==id){
                 break;
               }
           }
            delete_img.splice(i,1);
      }




});
